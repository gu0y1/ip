package istella;

public class IstellaException extends Exception {
    public IstellaException(String message) {
        super(message);
    }
}
